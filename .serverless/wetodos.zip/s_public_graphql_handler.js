var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'anxing',
applicationName: 'wetodos',
appUid: 'ZHgz0nDkc03QrkGHb1',
tenantUid: 'NR8Ym3Wpg5zHwyHxPz',
deploymentUid: 'dc7a17d9-4d11-47fc-9e5a-e14ca7a1c099',
serviceName: 'wetodos',
stageName: 'dev',
pluginVersion: '3.2.0'})
const handlerWrapperArgs = { functionName: 'wetodos-dev-public-graphql-handler', timeout: 6}
try {
  const userHandler = require('./src/graphql/public/handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
